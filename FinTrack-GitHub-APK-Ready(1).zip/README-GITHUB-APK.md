# FinTrack — One-Click GitHub APK Build

This project is configured so GitHub Actions can build a debug Android APK without Android Studio on your computer.

## First-time setup

1. Create a free GitHub account at https://github.com/ if you do not already have one.
2. Create a **new repository** (for example, `fintrack`). You can keep it private.
3. Upload the **contents** of this folder to the repository. The `.github/workflows/build-apk.yml` file must be present.
4. Open the repository on GitHub and select **Actions**.
5. Select **Build FinTrack APK**.
6. Click **Run workflow** and then **Run workflow** again.
7. Wait for the green check mark.
8. Open the completed workflow run and scroll to **Artifacts**.
9. Download **FinTrack-Android-APK**.
10. Extract it and install `app-debug.apk` on your Android phone.

## Automatic builds

The workflow also runs automatically whenever you push changes to the `main` branch.

## What this APK is

This is a debug APK intended for personal testing/use. It does not require your Node.js backend while running on Android. The Android build packages the `www` frontend into the application and uses the device's local storage for the app's offline data.

The PC/web version can continue using the Node.js backend separately.

## If GitHub shows an Actions permission warning

In the repository, open **Settings → Actions → General** and make sure GitHub Actions are allowed to run. The workflow only requests read access to repository contents.

## Important

Do not upload private passwords, API keys, database credentials, or other secrets into this repository.
