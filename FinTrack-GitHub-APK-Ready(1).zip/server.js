'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'ledger.json');
const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 4173);
const MAX_BODY = 5 * 1024 * 1024;

const DEFAULT_STATE = { categories: [], transactions: [] };

function ensureDataFile() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    atomicWrite(DEFAULT_STATE);
  }
}

function atomicWrite(state) {
  const payload = JSON.stringify({
    version: 1,
    updatedAt: new Date().toISOString(),
    categories: state.categories,
    transactions: state.transactions
  }, null, 2);
  const tmp = DATA_FILE + '.' + crypto.randomBytes(6).toString('hex') + '.tmp';
  fs.writeFileSync(tmp, payload, 'utf8');
  fs.renameSync(tmp, DATA_FILE);
}

function readState() {
  ensureDataFile();
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return {
      categories: Array.isArray(raw.categories) ? raw.categories : [],
      transactions: Array.isArray(raw.transactions) ? raw.transactions : []
    };
  } catch (err) {
    throw new Error('Ledger data is corrupted or unreadable. Restore it from a backup.');
  }
}

function validId(v) {
  return typeof v === 'string' && /^[A-Za-z0-9_-]{1,100}$/.test(v);
}

function validateState(value) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.categories) || !Array.isArray(value.transactions)) {
    return 'State must contain categories and transactions arrays.';
  }
  if (value.categories.length > 1000 || value.transactions.length > 100000) {
    return 'Ledger is larger than the supported limit.';
  }

  const categoryIds = new Set();
  for (const c of value.categories) {
    if (!c || !validId(c.id) || typeof c.name !== 'string' || !c.name.trim() || c.name.length > 200) {
      return 'Invalid account head.';
    }
    if (!['asset', 'liability', 'equity', 'income', 'expense'].includes(c.type)) {
      return 'Invalid account head type.';
    }
    if (categoryIds.has(c.id)) return 'Duplicate account head ID.';
    categoryIds.add(c.id);
  }

  for (const t of value.transactions) {
    if (!t || !validId(t.id) || !['income', 'expense'].includes(t.type)) return 'Invalid transaction.';
    if (!Number.isFinite(t.amount) || t.amount < 0 || t.amount > 1000000000000) return 'Invalid transaction amount.';
    if (typeof t.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(t.date)) return 'Invalid transaction date.';
    if (t.categoryId != null && (typeof t.categoryId !== 'string' || t.categoryId.length > 100)) return 'Invalid transaction category.';
    if (t.note != null && (typeof t.note !== 'string' || t.note.length > 1000)) return 'Invalid transaction note.';
  }
  return null;
}

function send(res, status, body, contentType = 'application/json; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
}

function json(res, status, value) {
  send(res, status, JSON.stringify(value));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error('Request too large.'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.css': 'text/css; charset=utf-8',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json'
};

function serveStatic(req, res, pathname) {
  let requested = pathname === '/' ? '/index.html' : pathname;
  let decoded;
  try { decoded = decodeURIComponent(requested); } catch { return json(res, 400, { error: 'Bad URL.' }); }
  const filePath = path.resolve(PUBLIC_DIR, '.' + decoded);
  if (!filePath.startsWith(path.resolve(PUBLIC_DIR) + path.sep)) return json(res, 403, { error: 'Forbidden.' });
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) return json(res, 404, { error: 'Not found.' });
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff'
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (pathname === '/api/health' && req.method === 'GET') {
      return json(res, 200, { ok: true, service: 'fintrack-backend', time: new Date().toISOString() });
    }

    if (pathname === '/api/state' && req.method === 'GET') {
      return json(res, 200, readState());
    }

    if (pathname === '/api/state' && req.method === 'PUT') {
      const body = await readBody(req);
      let state;
      try { state = JSON.parse(body); } catch { return json(res, 400, { error: 'Invalid JSON.' }); }
      const error = validateState(state);
      if (error) return json(res, 422, { error });
      atomicWrite(state);
      return json(res, 200, { ok: true, savedAt: new Date().toISOString() });
    }

    if (pathname === '/api/state' && req.method !== 'GET' && req.method !== 'PUT') {
      return json(res, 405, { error: 'Method not allowed.' });
    }

    return serveStatic(req, res, pathname);
  } catch (err) {
    console.error(err);
    const status = err.statusCode || 500;
    return json(res, status, { error: err.message || 'Internal server error.' });
  }
});

ensureDataFile();
server.listen(PORT, HOST, () => {
  console.log(`FinTrack running at http://${HOST}:${PORT}`);
  console.log(`Ledger data: ${DATA_FILE}`);
});
