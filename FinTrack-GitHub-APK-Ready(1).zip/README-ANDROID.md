# FinTrack Android / Capacitor Build

This project converts the existing FinTrack web app into an Android Studio / Capacitor project.

## Important architecture change

The original desktop version uses the Node.js backend at `/api/state`. Android cannot depend on that desktop Node server, so the Android build stores the ledger in persistent WebView `localStorage` when loaded from the Capacitor hostname `fintrack.local`.

The desktop Node backend remains available for the PC version.

## Requirements

- Node.js 20+ (Node 22 LTS recommended)
- Android Studio
- Android SDK / SDK Platform installed through Android Studio
- Android SDK Build-Tools
- Android SDK Platform-Tools
- Java JDK 17 or the JDK bundled with a current Android Studio installation

## First-time setup

Open a terminal in this project folder:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio will open the generated `android/` project.

## Build an APK

In Android Studio:

1. Let Gradle finish syncing.
2. Connect an Android phone with USB debugging enabled, or create an Android emulator.
3. For a test APK use **Build > Build APK(s)**.
4. The debug APK will normally be under:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

You can also build from a terminal after Android has been added:

```bash
cd android
./gradlew assembleDebug
```

On Windows:

```bat
cd android
gradlew.bat assembleDebug
```

## Release APK / Play Store

For a signed production build, use Android Studio's **Build > Generate Signed Bundle / APK**. For Google Play, choose **Android App Bundle (AAB)** rather than APK.

## Data

The Android version is offline-first. Ledger data persists on the device. It does not automatically synchronize with the PC Node.js backend. Use the app's existing export/backup features to move data between devices until cloud synchronization is added.
