# FinTrack — Full-Stack Local App

FinTrack is a personal finance ledger. This version keeps the existing browser UI but replaces browser-only ledger persistence with a real local backend.

## What was wrong with the original package

- **Frontend:** broadly functional and the JavaScript syntax is valid, but it was a single 1.2 MB HTML file containing the entire UI, CSS and Excel library.
- **Backend:** there was **no backend**. Ledger data was stored only in `localStorage` under `ledger-data`.
- **Data durability:** clearing browser data, changing browser profiles, or moving to another device could remove the ledger unless the user exported a backup.
- **PWA caching:** the original service worker cached requests too broadly and could interfere with future API requests.
- **Security boundary:** the PIN/app-lock protected the UI on the device; it was not server-side authentication.

## What this package changes

- Adds a Node.js backend (`server.js`).
- Stores the ledger in `data/ledger.json` with atomic writes.
- Adds `GET /api/health`, `GET /api/state`, and `PUT /api/state`.
- Validates account heads and transactions before saving.
- Keeps app-lock/PIN settings on the device.
- Updates the frontend persistence layer to use the backend.
- Updates the service worker so API requests are never cached.
- No third-party npm dependencies are required.

## Run

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:

```bash
npm start
```

4. Open `http://127.0.0.1:4173`.

The server intentionally binds to `127.0.0.1` by default, so the backend is local to the PC. **Do not expose this server directly to the internet or a public network without adding real authentication and HTTPS.**

## Data location

Your ledger is saved to:

`data/ledger.json`

The in-app JSON/Excel backup features still work and should be used for portable backups.

## Architecture

```text
Browser / PWA
     |
     | HTTP same-origin API
     v
Node.js server
     |
     v
 data/ledger.json
```

For a production multi-user version, the next step would be a database such as PostgreSQL/SQLite plus user authentication, CSRF protection, encrypted secrets, audit logging and server-side authorization.
