import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fintrack.app',
  appName: 'FinTrack',
  webDir: 'www',
  bundledWebRuntime: false,
  server: {
    hostname: 'fintrack.local',
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: false
  }
};

export default config;
